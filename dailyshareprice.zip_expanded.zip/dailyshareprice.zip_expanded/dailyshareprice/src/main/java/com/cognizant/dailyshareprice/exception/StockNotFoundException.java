package com.cognizant.dailyshareprice.exception;

public class StockNotFoundException extends Exception {

	public StockNotFoundException(String string) {
		super(string);
	}

}
