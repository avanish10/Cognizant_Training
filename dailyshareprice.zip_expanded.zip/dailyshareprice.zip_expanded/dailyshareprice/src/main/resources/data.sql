insert into stockdetails values ('DEL','Delloite',2500.0);
insert into stockdetails values ('AMZ','Amazon',1500.0);
insert into stockdetails values ('GGL','Google',1400.0);
insert into stockdetails values ('FFB','FaceBook',2000.0);