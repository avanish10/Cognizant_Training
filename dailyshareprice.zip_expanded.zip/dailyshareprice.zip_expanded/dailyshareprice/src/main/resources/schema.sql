DROP TABLE IF EXISTS stockdetails; 
create table stockdetails (stock_id varchar(10) primary key,stock_name varchar(50),stock_value DOUBLE);